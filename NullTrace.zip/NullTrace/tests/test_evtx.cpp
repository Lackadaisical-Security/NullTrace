//
// test_evtx.cpp - NullTrace Driver Test Application
// © Lackadaisical Security, 2025
//

#include <windows.h>
#include <iostream>
#include <vector>
#include <iomanip>
#include <string>

//
// Driver interface definitions
//
#define NULLTRACE_DEVICE_SYMLINK    L"\\\\.\\NullTrace"

#define IOCTL_NULLTRACE_STATS \
    CTL_CODE(FILE_DEVICE_UNKNOWN, 0x800, METHOD_BUFFERED, FILE_ANY_ACCESS)

typedef struct _NULLTRACE_STATS {
    ULONG64 TotalBytesDropped;
    ULONG64 TotalFilesIntercepted;
    ULONG64 TotalWritesBlocked;
    ULONG64 TotalCreatesCaptured;
    ULONG64 TotalSetInfoBlocked;
    ULONG   RingBufferOverflows;
    ULONG   CurrentRingBufferUsage;
    LARGE_INTEGER DriverStartTime;
} NULLTRACE_STATS, *PNULLTRACE_STATS;

//
// Test configuration
//
#define TEST_DATA_SIZE      (1024 * 1024)  // 1 MB
#define TEST_EVTX_PATH      L"C:\\Windows\\System32\\winevt\\Logs\\Application.evtx"
#define TEST_LOG_PATH       L"C:\\Temp\\test.log"
#define TEST_NORMAL_PATH    L"C:\\Temp\\normal.txt"

//
// Helper functions
//
void PrintError(const std::wstring& operation, DWORD error = GetLastError()) {
    std::wcout << L"[ERROR] " << operation << L" failed: 0x" 
               << std::hex << error << std::dec << std::endl;
}

void PrintSuccess(const std::wstring& message) {
    std::wcout << L"[SUCCESS] " << message << std::endl;
}

void PrintInfo(const std::wstring& message) {
    std::wcout << L"[INFO] " << message << std::endl;
}

void PrintStats(const NULLTRACE_STATS& stats) {
    std::wcout << L"\n=== NullTrace Driver Statistics ===" << std::endl;
    std::wcout << L"Total Bytes Dropped:      " << stats.TotalBytesDropped << std::endl;
    std::wcout << L"Total Files Intercepted:  " << stats.TotalFilesIntercepted << std::endl;
    std::wcout << L"Total Writes Blocked:     " << stats.TotalWritesBlocked << std::endl;
    std::wcout << L"Total Creates Captured:   " << stats.TotalCreatesCaptured << std::endl;
    std::wcout << L"Total SetInfo Blocked:    " << stats.TotalSetInfoBlocked << std::endl;
    std::wcout << L"Ring Buffer Overflows:    " << stats.RingBufferOverflows << std::endl;
    std::wcout << L"Ring Buffer Usage:        " << stats.CurrentRingBufferUsage << L" bytes" << std::endl;
    
    // Format driver start time
    SYSTEMTIME sysTime;
    FILETIME fileTime;
    fileTime.dwLowDateTime = stats.DriverStartTime.LowPart;
    fileTime.dwHighDateTime = stats.DriverStartTime.HighPart;
    
    if (FileTimeToSystemTime(&fileTime, &sysTime)) {
        std::wcout << L"Driver Start Time:        " 
                   << std::setfill(L'0') << std::setw(2) << sysTime.wMonth << L"/"
                   << std::setfill(L'0') << std::setw(2) << sysTime.wDay << L"/"
                   << sysTime.wYear << L" "
                   << std::setfill(L'0') << std::setw(2) << sysTime.wHour << L":"
                   << std::setfill(L'0') << std::setw(2) << sysTime.wMinute << L":"
                   << std::setfill(L'0') << std::setw(2) << sysTime.wSecond 
                   << std::endl;
    }
    std::wcout << L"===================================" << std::endl;
}

HANDLE OpenDriverDevice() {
    HANDLE deviceHandle = CreateFileW(
        NULLTRACE_DEVICE_SYMLINK,
        GENERIC_READ | GENERIC_WRITE,
        FILE_SHARE_READ | FILE_SHARE_WRITE,
        NULL,
        OPEN_EXISTING,
        FILE_ATTRIBUTE_NORMAL,
        NULL
    );

    if (deviceHandle == INVALID_HANDLE_VALUE) {
        PrintError(L"Opening driver device");
        return INVALID_HANDLE_VALUE;
    }

    PrintSuccess(L"Opened driver device");
    return deviceHandle;
}

bool GetDriverStats(HANDLE deviceHandle, NULLTRACE_STATS& stats) {
    DWORD bytesReturned;
    
    BOOL result = DeviceIoControl(
        deviceHandle,
        IOCTL_NULLTRACE_STATS,
        NULL,
        0,
        &stats,
        sizeof(stats),
        &bytesReturned,
        NULL
    );

    if (!result) {
        PrintError(L"Getting driver statistics");
        return false;
    }

    if (bytesReturned != sizeof(stats)) {
        PrintError(L"Invalid statistics size returned");
        return false;
    }

    return true;
}

bool WriteTestFile(const std::wstring& filePath, const std::vector<BYTE>& data, bool expectSuccess = false) {
    PrintInfo(L"Testing write to: " + filePath);

    HANDLE fileHandle = CreateFileW(
        filePath.c_str(),
        GENERIC_WRITE,
        0,
        NULL,
        CREATE_ALWAYS,
        FILE_ATTRIBUTE_NORMAL,
        NULL
    );

    if (fileHandle == INVALID_HANDLE_VALUE) {
        PrintError(L"Creating test file: " + filePath);
        return false;
    }

    DWORD bytesWritten;
    BOOL writeResult = WriteFile(
        fileHandle,
        data.data(),
        static_cast<DWORD>(data.size()),
        &bytesWritten,
        NULL
    );

    CloseHandle(fileHandle);

    if (expectSuccess) {
        if (writeResult && bytesWritten == data.size()) {
            PrintSuccess(L"Write succeeded as expected");
            return true;
        } else {
            PrintError(L"Write failed unexpectedly");
            return false;
        }
    } else {
        if (writeResult && bytesWritten == data.size()) {
            PrintInfo(L"Write appeared to succeed (driver intercepted silently)");
            return true;
        } else {
            PrintError(L"Write failed");
            return false;
        }
    }
}

bool TestFileSetSize(const std::wstring& filePath) {
    PrintInfo(L"Testing SetFileInformation on: " + filePath);

    HANDLE fileHandle = CreateFileW(
        filePath.c_str(),
        GENERIC_WRITE,
        0,
        NULL,
        OPEN_EXISTING,
        FILE_ATTRIBUTE_NORMAL,
        NULL
    );

    if (fileHandle == INVALID_HANDLE_VALUE) {
        PrintError(L"Opening file for SetFileInformation test: " + filePath);
        return false;
    }

    // Try to set file size to 2MB
    LARGE_INTEGER newSize;
    newSize.QuadPart = 2 * 1024 * 1024;

    BOOL result = SetFilePointerEx(fileHandle, newSize, NULL, FILE_BEGIN);
    if (result) {
        result = SetEndOfFile(fileHandle);
    }

    CloseHandle(fileHandle);

    if (result) {
        PrintInfo(L"SetFileInformation appeared to succeed (driver may have intercepted)");
        return true;
    } else {
        PrintError(L"SetFileInformation failed");
        return false;
    }
}

void CreateTempDirectory() {
    CreateDirectoryW(L"C:\\Temp", NULL);
}

int main() {
    std::wcout << L"NullTrace Driver Test Application" << std::endl;
    std::wcout << L"© Lackadaisical Security, 2025" << std::endl;
    std::wcout << L"=================================" << std::endl << std::endl;

    // Create temp directory
    CreateTempDirectory();

    // Generate test data
    PrintInfo(L"Generating " + std::to_wstring(TEST_DATA_SIZE) + L" bytes of test data...");
    std::vector<BYTE> testData(TEST_DATA_SIZE);
    
    // Fill with pattern
    for (size_t i = 0; i < testData.size(); ++i) {
        testData[i] = static_cast<BYTE>(i & 0xFF);
    }

    // Open driver device
    HANDLE driverHandle = OpenDriverDevice();
    if (driverHandle == INVALID_HANDLE_VALUE) {
        std::wcout << L"Cannot communicate with driver. Ensure NullTrace is loaded." << std::endl;
        return 1;
    }

    // Get initial statistics
    NULLTRACE_STATS initialStats = {0};
    if (!GetDriverStats(driverHandle, initialStats)) {
        CloseHandle(driverHandle);
        return 1;
    }

    PrintInfo(L"Initial driver statistics:");
    PrintStats(initialStats);

    std::wcout << L"\n--- Starting Tests ---" << std::endl;

    // Test 1: Write to .evtx file (should be intercepted)
    std::wcout << L"\n1. Testing .evtx file write interception..." << std::endl;
    WriteTestFile(TEST_EVTX_PATH, testData, false);

    // Test 2: Write to .log file (should be intercepted)
    std::wcout << L"\n2. Testing .log file write interception..." << std::endl;
    WriteTestFile(TEST_LOG_PATH, testData, false);

    // Test 3: Write to normal file (should succeed normally)
    std::wcout << L"\n3. Testing normal file write (control test)..." << std::endl;
    WriteTestFile(TEST_NORMAL_PATH, testData, true);

    // Test 4: Test SetFileInformation on .log file
    std::wcout << L"\n4. Testing SetFileInformation interception on .log file..." << std::endl;
    TestFileSetSize(TEST_LOG_PATH);

    // Test 5: Test SetFileInformation on .evtx file  
    std::wcout << L"\n5. Testing SetFileInformation interception on .evtx file..." << std::endl;
    TestFileSetSize(TEST_EVTX_PATH);

    // Get final statistics
    std::wcout << L"\n--- Test Results ---" << std::endl;
    NULLTRACE_STATS finalStats = {0};
    if (GetDriverStats(driverHandle, finalStats)) {
        PrintInfo(L"Final driver statistics:");
        PrintStats(finalStats);

        // Calculate deltas
        std::wcout << L"\n--- Changes During Test ---" << std::endl;
        std::wcout << L"Bytes Dropped:       " << (finalStats.TotalBytesDropped - initialStats.TotalBytesDropped) << std::endl;
        std::wcout << L"Files Intercepted:   " << (finalStats.TotalFilesIntercepted - initialStats.TotalFilesIntercepted) << std::endl;
        std::wcout << L"Writes Blocked:      " << (finalStats.TotalWritesBlocked - initialStats.TotalWritesBlocked) << std::endl;
        std::wcout << L"Creates Captured:    " << (finalStats.TotalCreatesCaptured - initialStats.TotalCreatesCaptured) << std::endl;
        std::wcout << L"SetInfo Blocked:     " << (finalStats.TotalSetInfoBlocked - initialStats.TotalSetInfoBlocked) << std::endl;

        // Validate expected results
        std::wcout << L"\n--- Validation ---" << std::endl;
        bool testPassed = true;

        if ((finalStats.TotalWritesBlocked - initialStats.TotalWritesBlocked) >= 2) {
            PrintSuccess(L"Write interception working correctly");
        } else {
            PrintError(L"Expected at least 2 write operations to be blocked");
            testPassed = false;
        }

        if ((finalStats.TotalBytesDropped - initialStats.TotalBytesDropped) >= (TEST_DATA_SIZE * 2)) {
            PrintSuccess(L"Byte dropping working correctly");
        } else {
            PrintError(L"Expected at least " + std::to_wstring(TEST_DATA_SIZE * 2) + L" bytes to be dropped");
            testPassed = false;
        }

        if ((finalStats.TotalCreatesCaptured - initialStats.TotalCreatesCaptured) >= 2) {
            PrintSuccess(L"Create interception working correctly");
        } else {
            PrintError(L"Expected at least 2 create operations to be captured");
            testPassed = false;
        }

        if (testPassed) {
            PrintSuccess(L"All tests PASSED! NullTrace is working correctly.");
        } else {
            PrintError(L"Some tests FAILED. Check driver implementation.");
        }
    }

    // Cleanup
    CloseHandle(driverHandle);
    
    // Clean up test files
    DeleteFileW(TEST_LOG_PATH);
    DeleteFileW(TEST_NORMAL_PATH);
    // Note: Don't delete the system .evtx file

    std::wcout << L"\nPress Enter to exit...";
    std::wcin.get();
    return 0;
} 