//
// NullTrace.c - Production-Grade KMDF Anti-Forensics Driver
// © Lackadaisical Security, 2025
//

#include "NullTrace.h"

//
// Global driver data
//
NULLTRACE_GLOBAL_DATA g_NullTraceData = { 0 };

//
// Driver entry point
//
NTSTATUS
DriverEntry(
    _In_ PDRIVER_OBJECT DriverObject,
    _In_ PUNICODE_STRING RegistryPath
    )
{
    NTSTATUS status;
    WDF_DRIVER_CONFIG driverConfig;
    WDF_OBJECT_ATTRIBUTES driverAttributes;
    WDFDRIVER driver;

    DbgPrint("NullTrace: KMDF Driver loading...\n");

    //
    // Initialize global data
    //
    RtlZeroMemory(&g_NullTraceData, sizeof(g_NullTraceData));
    InitializeListHead(&g_NullTraceData.FilterDeviceList);
    KeInitializeSpinLock(&g_NullTraceData.FilterDeviceListLock);

    //
    // Configure WDF driver
    //
    WDF_DRIVER_CONFIG_INIT(&driverConfig, WDF_NO_EVENT_CALLBACK);
    driverConfig.EvtDriverUnload = NullTraceEvtDriverUnload;
    driverConfig.DriverInitFlags = WdfDriverInitNonPnpDriver;

    WDF_OBJECT_ATTRIBUTES_INIT(&driverAttributes);
    driverAttributes.SynchronizationScope = WdfSynchronizationScopeNone;

    //
    // Create WDF driver object
    //
    status = WdfDriverCreate(DriverObject, RegistryPath, &driverAttributes, &driverConfig, &driver);
    if (!NT_SUCCESS(status)) {
        DbgPrint("NullTrace: WdfDriverCreate failed: 0x%08X\n", status);
        return status;
    }

    g_NullTraceData.Driver = driver;

    //
    // Allocate ring buffer
    //
    g_NullTraceData.RingBuffer = (PUCHAR)ExAllocatePoolWithTag(
        NonPagedPool,
        NULLTRACE_RING_BUFFER_SIZE,
        NULLTRACE_POOL_TAG
    );

    if (g_NullTraceData.RingBuffer == NULL) {
        DbgPrint("NullTrace: Failed to allocate ring buffer\n");
        return STATUS_INSUFFICIENT_RESOURCES;
    }

    RtlZeroMemory(g_NullTraceData.RingBuffer, NULLTRACE_RING_BUFFER_SIZE);

    //
    // Create WDF spin locks
    //
    WDF_OBJECT_ATTRIBUTES spinLockAttrs;
    WDF_OBJECT_ATTRIBUTES_INIT(&spinLockAttrs);
    spinLockAttrs.ParentObject = driver;

    status = WdfSpinLockCreate(&spinLockAttrs, &g_NullTraceData.StatisticsLock);
    if (!NT_SUCCESS(status)) {
        DbgPrint("NullTrace: Failed to create statistics lock: 0x%08X\n", status);
        goto Cleanup;
    }

    status = WdfSpinLockCreate(&spinLockAttrs, &g_NullTraceData.RingBufferSpinLock);
    if (!NT_SUCCESS(status)) {
        DbgPrint("NullTrace: Failed to create ring buffer lock: 0x%08X\n", status);
        goto Cleanup;
    }

    //
    // Create lookaside lists
    //
    WDF_OBJECT_ATTRIBUTES lookasideAttrs;
    WDF_LOOKASIDE_LIST_CONFIG lookasideConfig;

    WDF_OBJECT_ATTRIBUTES_INIT(&lookasideAttrs);
    lookasideAttrs.ParentObject = driver;

    WDF_LOOKASIDE_LIST_CONFIG_INIT(&lookasideConfig, 
                                   sizeof(NULLTRACE_BUFFER_ENTRY) + 4096,
                                   NonPagedPool);
    lookasideConfig.PoolTag = NULLTRACE_POOL_TAG;

    status = WdfLookasideListCreate(&lookasideAttrs, &lookasideConfig, &g_NullTraceData.BufferEntryLookaside);
    if (!NT_SUCCESS(status)) {
        DbgPrint("NullTrace: Failed to create buffer entry lookaside: 0x%08X\n", status);
        goto Cleanup;
    }

    WDF_LOOKASIDE_LIST_CONFIG_INIT(&lookasideConfig, 
                                   NULLTRACE_MAX_FILENAME_LENGTH * sizeof(WCHAR),
                                   PagedPool);
    lookasideConfig.PoolTag = NULLTRACE_POOL_TAG;

    status = WdfLookasideListCreate(&lookasideAttrs, &lookasideConfig, &g_NullTraceData.FileNameLookaside);
    if (!NT_SUCCESS(status)) {
        DbgPrint("NullTrace: Failed to create filename lookaside: 0x%08X\n", status);
        goto Cleanup;
    }

    //
    // Initialize statistics
    //
    KeQuerySystemTime(&g_NullTraceData.Statistics.DriverStartTime);

    //
    // Create control device
    //
    status = NullTraceCreateControlDevice(driver);
    if (!NT_SUCCESS(status)) {
        DbgPrint("NullTrace: Failed to create control device: 0x%08X\n", status);
        goto Cleanup;
    }

    //
    // Set up IRP dispatch routines for all devices created by this driver
    //
    DriverObject->MajorFunction[IRP_MJ_CREATE] = NullTraceDispatchCreate;
    DriverObject->MajorFunction[IRP_MJ_WRITE] = NullTraceDispatchWrite;
    DriverObject->MajorFunction[IRP_MJ_SET_INFORMATION] = NullTraceDispatchSetInformation;
    DriverObject->MajorFunction[IRP_MJ_CLOSE] = NullTraceDispatchDefault;
    DriverObject->MajorFunction[IRP_MJ_CLEANUP] = NullTraceDispatchDefault;
    DriverObject->MajorFunction[IRP_MJ_READ] = NullTraceDispatchDefault;
    DriverObject->MajorFunction[IRP_MJ_QUERY_INFORMATION] = NullTraceDispatchDefault;
    DriverObject->MajorFunction[IRP_MJ_QUERY_VOLUME_INFORMATION] = NullTraceDispatchDefault;
    DriverObject->MajorFunction[IRP_MJ_DIRECTORY_CONTROL] = NullTraceDispatchDefault;
    DriverObject->MajorFunction[IRP_MJ_FILE_SYSTEM_CONTROL] = NullTraceDispatchDefault;
    DriverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL] = NullTraceDispatchDefault;
    DriverObject->MajorFunction[IRP_MJ_SHUTDOWN] = NullTraceDispatchDefault;
    DriverObject->MajorFunction[IRP_MJ_FLUSH_BUFFERS] = NullTraceDispatchDefault;
    DriverObject->MajorFunction[IRP_MJ_QUERY_SECURITY] = NullTraceDispatchDefault;
    DriverObject->MajorFunction[IRP_MJ_SET_SECURITY] = NullTraceDispatchDefault;

    //
    // Register for file system change notifications
    //
    status = IoRegisterFsRegistrationChange(DriverObject, NullTraceFileSystemNotification);
    if (!NT_SUCCESS(status)) {
        DbgPrint("NullTrace: Failed to register FS notification: 0x%08X\n", status);
        goto Cleanup;
    }

    //
    // Attach to existing file systems
    //
    NullTraceAttachToExistingFileSystems();

    DbgPrint("NullTrace: KMDF Driver loaded successfully\n");
    return STATUS_SUCCESS;

Cleanup:
    NullTraceSecureCleanup();
    return status;
}

//
// Driver unload event
//
VOID
NullTraceEvtDriverUnload(
    _In_ WDFDRIVER Driver
    )
{
    UNREFERENCED_PARAMETER(Driver);

    DbgPrint("NullTrace: Driver unloading...\n");

    g_NullTraceData.DriverUnloading = TRUE;

    //
    // Unregister file system change notification
    //
    IoUnregisterFsRegistrationChange(WdfDriverWdmGetDriverObject(Driver), NullTraceFileSystemNotification);

    //
    // Detach from all file systems
    //
    NullTraceDetachFromAllFileSystems();

    //
    // Secure cleanup
    //
    NullTraceSecureCleanup();

    DbgPrint("NullTrace: Driver unloaded\n");
}

//
// Device context cleanup event
//
VOID
NullTraceEvtDeviceContextCleanup(
    _In_ WDFOBJECT Device
    )
{
    PNULLTRACE_DEVICE_EXTENSION deviceExtension;

    deviceExtension = NullTraceGetDeviceExtension((WDFDEVICE)Device);

    if (deviceExtension->IsAttached && deviceExtension->AttachedToDeviceObject != NULL) {
        IoDetachDevice(deviceExtension->AttachedToDeviceObject);
        deviceExtension->AttachedToDeviceObject = NULL;
        deviceExtension->IsAttached = FALSE;
    }

    if (deviceExtension->DeviceName.Buffer != NULL) {
        ExFreePoolWithTag(deviceExtension->DeviceName.Buffer, NULLTRACE_POOL_TAG);
        deviceExtension->DeviceName.Buffer = NULL;
    }

    DbgPrint("NullTrace: Device context cleanup completed\n");
}

//
// Create control device for IOCTL communication
//
NTSTATUS
NullTraceCreateControlDevice(
    _In_ WDFDRIVER Driver
    )
{
    NTSTATUS status;
    WDFDEVICE controlDevice;
    WDF_DEVICE_INIT* deviceInit = NULL;
    WDF_OBJECT_ATTRIBUTES deviceAttributes;
    WDF_IO_QUEUE_CONFIG queueConfig;
    WDFQUEUE queue;
    UNICODE_STRING deviceName, symbolicLink;

    //
    // Allocate device init structure
    //
    deviceInit = WdfControlDeviceInitAllocate(Driver, &SDDL_DEVOBJ_SYS_ALL_ADM_RWX_WORLD_RWX_RES_RWX);
    if (deviceInit == NULL) {
        status = STATUS_INSUFFICIENT_RESOURCES;
        goto Cleanup;
    }

    RtlInitUnicodeString(&deviceName, NULLTRACE_DEVICE_NAME);
    status = WdfDeviceInitAssignName(deviceInit, &deviceName);
    if (!NT_SUCCESS(status)) {
        goto Cleanup;
    }

    //
    // Set device attributes
    //
    WDF_OBJECT_ATTRIBUTES_INIT(&deviceAttributes);
    deviceAttributes.SynchronizationScope = WdfSynchronizationScopeNone;

    //
    // Create control device
    //
    status = WdfDeviceCreate(&deviceInit, &deviceAttributes, &controlDevice);
    if (!NT_SUCCESS(status)) {
        goto Cleanup;
    }

    g_NullTraceData.ControlDevice = controlDevice;

    //
    // Create symbolic link
    //
    RtlInitUnicodeString(&symbolicLink, NULLTRACE_SYMBOLIC_LINK);
    status = WdfDeviceCreateSymbolicLink(controlDevice, &symbolicLink);
    if (!NT_SUCCESS(status)) {
        goto Cleanup;
    }

    //
    // Create I/O queue for device control requests
    //
    WDF_IO_QUEUE_CONFIG_INIT_DEFAULT_QUEUE(&queueConfig, WdfIoQueueDispatchParallel);
    queueConfig.EvtIoDeviceControl = NullTraceEvtIoDeviceControl;

    status = WdfIoQueueCreate(controlDevice, &queueConfig, WDF_NO_OBJECT_ATTRIBUTES, &queue);
    if (!NT_SUCCESS(status)) {
        goto Cleanup;
    }

    //
    // Finish initializing the control device
    //
    WdfControlFinishInitializing(controlDevice);

    return STATUS_SUCCESS;

Cleanup:
    if (deviceInit != NULL) {
        WdfDeviceInitFree(deviceInit);
    }
    return status;
}

//
// Device control I/O event
//
VOID
NullTraceEvtIoDeviceControl(
    _In_ WDFQUEUE Queue,
    _In_ WDFREQUEST Request,
    _In_ size_t OutputBufferLength,
    _In_ size_t InputBufferLength,
    _In_ ULONG IoControlCode
    )
{
    NTSTATUS status = STATUS_INVALID_DEVICE_REQUEST;
    PVOID outputBuffer = NULL;
    size_t bytesReturned = 0;

    UNREFERENCED_PARAMETER(Queue);
    UNREFERENCED_PARAMETER(InputBufferLength);

    switch (IoControlCode) {
    case IOCTL_NULLTRACE_STATS:
        if (OutputBufferLength >= sizeof(NULLTRACE_STATS)) {
            status = WdfRequestRetrieveOutputBuffer(Request, sizeof(NULLTRACE_STATS), &outputBuffer, NULL);
            if (NT_SUCCESS(status)) {
                WdfSpinLockAcquire(g_NullTraceData.StatisticsLock);
                RtlCopyMemory(outputBuffer, &g_NullTraceData.Statistics, sizeof(NULLTRACE_STATS));
                WdfSpinLockRelease(g_NullTraceData.StatisticsLock);
                bytesReturned = sizeof(NULLTRACE_STATS);
                status = STATUS_SUCCESS;
            }
        } else {
            status = STATUS_BUFFER_TOO_SMALL;
        }
        break;

    default:
        status = STATUS_INVALID_DEVICE_REQUEST;
        break;
    }

    WdfRequestCompleteWithInformation(Request, status, bytesReturned);
}

//
// IRP_MJ_CREATE dispatch routine
//
NTSTATUS
NullTraceDispatchCreate(
    _In_ PDEVICE_OBJECT DeviceObject,
    _In_ PIRP Irp
    )
{
    NTSTATUS status;
    PNULLTRACE_DEVICE_EXTENSION deviceExtension;
    UNICODE_STRING fileName = { 0 };
    BOOLEAN isTargetFile = FALSE;
    PIO_STACK_LOCATION irpStack;

    //
    // Check if this is our control device
    //
    if (DeviceObject == WdfDeviceWdmGetDeviceObject(g_NullTraceData.ControlDevice)) {
        Irp->IoStatus.Status = STATUS_SUCCESS;
        Irp->IoStatus.Information = 0;
        IoCompleteRequest(Irp, IO_NO_INCREMENT);
        return STATUS_SUCCESS;
    }

    //
    // Get device extension
    //
    deviceExtension = NullTraceGetDeviceExtension(WdfDeviceGetWdfDeviceObject(DeviceObject));

    //
    // Safety checks
    //
    if (!NullTraceSafeToFilter(Irp) || g_NullTraceData.DriverUnloading || !deviceExtension->IsAttached) {
        return NullTraceDispatchDefault(DeviceObject, Irp);
    }

    //
    // Get file name from IRP
    //
    status = NullTraceGetFileNameFromIrp(Irp, &fileName);
    if (NT_SUCCESS(status)) {
        isTargetFile = NullTraceIsTargetFile(&fileName);

        if (isTargetFile) {
            DbgPrint("NullTrace: CREATE intercepted for: %wZ\n", &fileName);
            
            //
            // Log the create operation
            //
            NullTraceAddToRingBuffer(1, &fileName, NULL, 0);
            
            //
            // Update statistics
            //
            NullTraceUpdateStatistics(0, TRUE, FALSE, TRUE, FALSE);
        }

        NullTraceFreeFileName(&fileName);
    }

    //
    // Set up completion routine if this is a target file
    //
    if (isTargetFile) {
        IoCopyCurrentIrpStackLocationToNext(Irp);
        IoSetCompletionRoutine(Irp, NullTraceCreateCompletion, DeviceObject, TRUE, TRUE, TRUE);
        return IoCallDriver(deviceExtension->AttachedToDeviceObject, Irp);
    }

    //
    // Forward to next driver
    //
    return NullTraceDispatchDefault(DeviceObject, Irp);
}

//
// IRP_MJ_WRITE dispatch routine
//
NTSTATUS
NullTraceDispatchWrite(
    _In_ PDEVICE_OBJECT DeviceObject,
    _In_ PIRP Irp
    )
{
    NTSTATUS status;
    PNULLTRACE_DEVICE_EXTENSION deviceExtension;
    UNICODE_STRING fileName = { 0 };
    BOOLEAN isTargetFile = FALSE;
    PIO_STACK_LOCATION irpStack;
    ULONG writeLength;
    PVOID writeBuffer;

    //
    // Check if this is our control device
    //
    if (DeviceObject == WdfDeviceWdmGetDeviceObject(g_NullTraceData.ControlDevice)) {
        Irp->IoStatus.Status = STATUS_INVALID_DEVICE_REQUEST;
        Irp->IoStatus.Information = 0;
        IoCompleteRequest(Irp, IO_NO_INCREMENT);
        return STATUS_INVALID_DEVICE_REQUEST;
    }

    //
    // Get device extension
    //
    deviceExtension = NullTraceGetDeviceExtension(WdfDeviceGetWdfDeviceObject(DeviceObject));

    //
    // Safety checks
    //
    if (!NullTraceSafeToFilter(Irp) || g_NullTraceData.DriverUnloading || !deviceExtension->IsAttached) {
        return NullTraceDispatchDefault(DeviceObject, Irp);
    }

    //
    // Get file name from IRP
    //
    status = NullTraceGetFileNameFromIrp(Irp, &fileName);
    if (NT_SUCCESS(status)) {
        isTargetFile = NullTraceIsTargetFile(&fileName);

        if (isTargetFile) {
            irpStack = IoGetCurrentIrpStackLocation(Irp);
            writeLength = irpStack->Parameters.Write.Length;
            writeBuffer = Irp->UserBuffer; // or MmGetSystemAddressForMdlSafe if MDL

            DbgPrint("NullTrace: WRITE blocked for: %wZ (%u bytes)\n", &fileName, writeLength);

            //
            // Add data to ring buffer if we can get it safely
            //
            if (writeLength > 0 && writeBuffer != NULL) {
                __try {
                    NullTraceAddToRingBuffer(2, &fileName, writeBuffer, writeLength);
                } __except(EXCEPTION_EXECUTE_HANDLER) {
                    // Continue even if we can't capture the data
                }
            }

            //
            // Update statistics
            //
            NullTraceUpdateStatistics(writeLength, FALSE, TRUE, FALSE, FALSE);

            //
            // Complete request successfully without forwarding (sink the write)
            //
            Irp->IoStatus.Status = STATUS_SUCCESS;
            Irp->IoStatus.Information = writeLength;
            IoCompleteRequest(Irp, IO_NO_INCREMENT);

            NullTraceFreeFileName(&fileName);
            return STATUS_SUCCESS;
        }

        NullTraceFreeFileName(&fileName);
    }

    //
    // Forward to next driver
    //
    return NullTraceDispatchDefault(DeviceObject, Irp);
}

//
// IRP_MJ_SET_INFORMATION dispatch routine
//
NTSTATUS
NullTraceDispatchSetInformation(
    _In_ PDEVICE_OBJECT DeviceObject,
    _In_ PIRP Irp
    )
{
    NTSTATUS status;
    PNULLTRACE_DEVICE_EXTENSION deviceExtension;
    UNICODE_STRING fileName = { 0 };
    BOOLEAN isTargetFile = FALSE;
    PIO_STACK_LOCATION irpStack;
    FILE_INFORMATION_CLASS infoClass;

    //
    // Check if this is our control device
    //
    if (DeviceObject == WdfDeviceWdmGetDeviceObject(g_NullTraceData.ControlDevice)) {
        Irp->IoStatus.Status = STATUS_INVALID_DEVICE_REQUEST;
        Irp->IoStatus.Information = 0;
        IoCompleteRequest(Irp, IO_NO_INCREMENT);
        return STATUS_INVALID_DEVICE_REQUEST;
    }

    //
    // Get device extension
    //
    deviceExtension = NullTraceGetDeviceExtension(WdfDeviceGetWdfDeviceObject(DeviceObject));

    //
    // Safety checks
    //
    if (!NullTraceSafeToFilter(Irp) || g_NullTraceData.DriverUnloading || !deviceExtension->IsAttached) {
        return NullTraceDispatchDefault(DeviceObject, Irp);
    }

    irpStack = IoGetCurrentIrpStackLocation(Irp);
    infoClass = irpStack->Parameters.SetFile.FileInformationClass;

    //
    // Only intercept specific information classes
    //
    if (infoClass != FileEndOfFileInformation && 
        infoClass != FileAllocationInformation &&
        infoClass != FileValidDataLengthInformation) {
        return NullTraceDispatchDefault(DeviceObject, Irp);
    }

    //
    // Get file name from IRP
    //
    status = NullTraceGetFileNameFromIrp(Irp, &fileName);
    if (NT_SUCCESS(status)) {
        isTargetFile = NullTraceIsTargetFile(&fileName);

        if (isTargetFile) {
            DbgPrint("NullTrace: SET_INFORMATION blocked for: %wZ\n", &fileName);

            //
            // Log the operation
            //
            NullTraceAddToRingBuffer(3, &fileName, NULL, 0);

            //
            // Update statistics
            //
            NullTraceUpdateStatistics(0, FALSE, FALSE, FALSE, TRUE);

            //
            // Complete request successfully without forwarding
            //
            Irp->IoStatus.Status = STATUS_SUCCESS;
            Irp->IoStatus.Information = 0;
            IoCompleteRequest(Irp, IO_NO_INCREMENT);

            NullTraceFreeFileName(&fileName);
            return STATUS_SUCCESS;
        }

        NullTraceFreeFileName(&fileName);
    }

    //
    // Forward to next driver
    //
    return NullTraceDispatchDefault(DeviceObject, Irp);
}

//
// Default dispatch routine for forwarding IRPs
//
NTSTATUS
NullTraceDispatchDefault(
    _In_ PDEVICE_OBJECT DeviceObject,
    _In_ PIRP Irp
    )
{
    PNULLTRACE_DEVICE_EXTENSION deviceExtension;

    //
    // Check if this is our control device
    //
    if (DeviceObject == WdfDeviceWdmGetDeviceObject(g_NullTraceData.ControlDevice)) {
        Irp->IoStatus.Status = STATUS_INVALID_DEVICE_REQUEST;
        Irp->IoStatus.Information = 0;
        IoCompleteRequest(Irp, IO_NO_INCREMENT);
        return STATUS_INVALID_DEVICE_REQUEST;
    }

    //
    // Get device extension
    //
    deviceExtension = NullTraceGetDeviceExtension(WdfDeviceGetWdfDeviceObject(DeviceObject));

    if (!deviceExtension->IsAttached) {
        Irp->IoStatus.Status = STATUS_INVALID_DEVICE_REQUEST;
        Irp->IoStatus.Information = 0;
        IoCompleteRequest(Irp, IO_NO_INCREMENT);
        return STATUS_INVALID_DEVICE_REQUEST;
    }

    //
    // Forward IRP to next driver
    //
    IoSkipCurrentIrpStackLocation(Irp);
    return IoCallDriver(deviceExtension->AttachedToDeviceObject, Irp);
}

//
// File system notification callback
//
VOID
NullTraceFileSystemNotification(
    _In_ PDEVICE_OBJECT DeviceObject,
    _In_ BOOLEAN FsActive
    )
{
    if (FsActive) {
        DbgPrint("NullTrace: File system activated: %p\n", DeviceObject);
        NullTraceAttachToFileSystem(DeviceObject);
    } else {
        DbgPrint("NullTrace: File system deactivated: %p\n", DeviceObject);
        // Device will be cleaned up when the device object is deleted
    }
}

//
// Attach to a file system
//
NTSTATUS
NullTraceAttachToFileSystem(
    _In_ PDEVICE_OBJECT FileSystemDeviceObject
    )
{
    NTSTATUS status;
    WDFDEVICE filterDevice;
    PNULLTRACE_DEVICE_EXTENSION deviceExtension;
    WDF_DEVICE_INIT* deviceInit = NULL;
    WDF_OBJECT_ATTRIBUTES deviceAttributes;
    PDEVICE_OBJECT attachedDevice;
    UNICODE_STRING deviceName;
    WCHAR deviceNameBuffer[64];

    if (g_NullTraceData.DriverUnloading) {
        return STATUS_UNSUCCESSFUL;
    }

    //
    // Create a unique device name
    //
    RtlStringCchPrintfW(deviceNameBuffer, ARRAYSIZE(deviceNameBuffer), 
                        L"\\Device\\NullTraceFilter%p", FileSystemDeviceObject);
    RtlInitUnicodeString(&deviceName, deviceNameBuffer);

    //
    // Allocate device init
    //
    deviceInit = WdfControlDeviceInitAllocate(g_NullTraceData.Driver, &SDDL_DEVOBJ_KERNEL_ONLY);
    if (deviceInit == NULL) {
        return STATUS_INSUFFICIENT_RESOURCES;
    }

    status = WdfDeviceInitAssignName(deviceInit, &deviceName);
    if (!NT_SUCCESS(status)) {
        WdfDeviceInitFree(deviceInit);
        return status;
    }

    //
    // Set device attributes
    //
    WDF_OBJECT_ATTRIBUTES_INIT_CONTEXT_TYPE(&deviceAttributes, NULLTRACE_DEVICE_EXTENSION);
    deviceAttributes.EvtCleanupCallback = NullTraceEvtDeviceContextCleanup;
    deviceAttributes.SynchronizationScope = WdfSynchronizationScopeNone;

    //
    // Create filter device
    //
    status = WdfDeviceCreate(&deviceInit, &deviceAttributes, &filterDevice);
    if (!NT_SUCCESS(status)) {
        WdfDeviceInitFree(deviceInit);
        return status;
    }

    //
    // Initialize device extension
    //
    deviceExtension = NullTraceGetDeviceExtension(filterDevice);
    RtlZeroMemory(deviceExtension, sizeof(NULLTRACE_DEVICE_EXTENSION));
    deviceExtension->Device = filterDevice;
    deviceExtension->FileSystemDeviceObject = FileSystemDeviceObject;

    //
    // Copy device name
    //
    deviceExtension->DeviceName.MaximumLength = deviceName.Length + sizeof(WCHAR);
    deviceExtension->DeviceName.Buffer = (PWCH)ExAllocatePoolWithTag(
        PagedPool, 
        deviceExtension->DeviceName.MaximumLength, 
        NULLTRACE_POOL_TAG
    );
    
    if (deviceExtension->DeviceName.Buffer != NULL) {
        RtlCopyUnicodeString(&deviceExtension->DeviceName, &deviceName);
    }

    //
    // Attach to the file system device stack
    //
    attachedDevice = IoAttachDeviceToDeviceStack(
        WdfDeviceWdmGetDeviceObject(filterDevice),
        FileSystemDeviceObject
    );

    if (attachedDevice == NULL) {
        DbgPrint("NullTrace: Failed to attach to file system device\n");
        WdfObjectDelete(filterDevice);
        return STATUS_UNSUCCESSFUL;
    }

    deviceExtension->AttachedToDeviceObject = attachedDevice;
    deviceExtension->IsAttached = TRUE;

    //
    // Set device flags to match the target device
    //
    WdfDeviceWdmGetDeviceObject(filterDevice)->Flags |= 
        (FileSystemDeviceObject->Flags & (DO_BUFFERED_IO | DO_DIRECT_IO));
    WdfDeviceWdmGetDeviceObject(filterDevice)->DeviceType = FileSystemDeviceObject->DeviceType;
    WdfDeviceWdmGetDeviceObject(filterDevice)->Characteristics = FileSystemDeviceObject->Characteristics;

    //
    // Clear the initializing flag
    //
    WdfDeviceWdmGetDeviceObject(filterDevice)->Flags &= ~DO_DEVICE_INITIALIZING;

    //
    // Add to our device list
    //
    KIRQL oldIrql;
    KeAcquireSpinLock(&g_NullTraceData.FilterDeviceListLock, &oldIrql);
    InsertTailList(&g_NullTraceData.FilterDeviceList, &deviceExtension->ListEntry);
    KeReleaseSpinLock(&g_NullTraceData.FilterDeviceListLock, oldIrql);

    DbgPrint("NullTrace: Successfully attached to file system: %wZ\n", &deviceExtension->DeviceName);
    return STATUS_SUCCESS;
}

//
// Attach to existing file systems
//
VOID
NullTraceAttachToExistingFileSystems(
    VOID
    )
{
    NTSTATUS status;
    UNICODE_STRING ntfsName, fastfatName;
    PFILE_OBJECT fileObject;
    PDEVICE_OBJECT deviceObject;

    //
    // Attach to NTFS
    //
    RtlInitUnicodeString(&ntfsName, NTFS_DEVICE_NAME);
    status = IoGetDeviceObjectPointer(&ntfsName, FILE_READ_ATTRIBUTES, &fileObject, &deviceObject);
    if (NT_SUCCESS(status)) {
        NullTraceAttachToFileSystem(deviceObject);
        ObDereferenceObject(fileObject);
    }

    //
    // Attach to FAT
    //
    RtlInitUnicodeString(&fastfatName, FASTFAT_DEVICE_NAME);
    status = IoGetDeviceObjectPointer(&fastfatName, FILE_READ_ATTRIBUTES, &fileObject, &deviceObject);
    if (NT_SUCCESS(status)) {
        NullTraceAttachToFileSystem(deviceObject);
        ObDereferenceObject(fileObject);
    }
}

//
// Detach from all file systems
//
VOID
NullTraceDetachFromAllFileSystems(
    VOID
    )
{
    KIRQL oldIrql;
    PLIST_ENTRY entry;
    PNULLTRACE_DEVICE_EXTENSION deviceExtension;

    KeAcquireSpinLock(&g_NullTraceData.FilterDeviceListLock, &oldIrql);

    while (!IsListEmpty(&g_NullTraceData.FilterDeviceList)) {
        entry = RemoveHeadList(&g_NullTraceData.FilterDeviceList);
        deviceExtension = CONTAINING_RECORD(entry, NULLTRACE_DEVICE_EXTENSION, ListEntry);
        
        KeReleaseSpinLock(&g_NullTraceData.FilterDeviceListLock, oldIrql);
        
        if (deviceExtension->IsAttached) {
            WdfObjectDelete(deviceExtension->Device);
        }
        
        KeAcquireSpinLock(&g_NullTraceData.FilterDeviceListLock, &oldIrql);
    }

    KeReleaseSpinLock(&g_NullTraceData.FilterDeviceListLock, oldIrql);
}

//
// Create completion routine (for future use)
//
NTSTATUS
NullTraceCreateCompletion(
    _In_ PDEVICE_OBJECT DeviceObject,
    _In_ PIRP Irp,
    _In_ PVOID Context
    )
{
    UNREFERENCED_PARAMETER(DeviceObject);
    UNREFERENCED_PARAMETER(Context);

    // Just pass through for now
    if (Irp->PendingReturned) {
        IoMarkIrpPending(Irp);
    }

    return STATUS_SUCCESS;
}

//
// Write completion routine (for future use)
//
NTSTATUS
NullTraceWriteCompletion(
    _In_ PDEVICE_OBJECT DeviceObject,
    _In_ PIRP Irp,
    _In_ PVOID Context
    )
{
    UNREFERENCED_PARAMETER(DeviceObject);
    UNREFERENCED_PARAMETER(Context);

    if (Irp->PendingReturned) {
        IoMarkIrpPending(Irp);
    }

    return STATUS_SUCCESS;
}

//
// Set info completion routine (for future use)
//
NTSTATUS
NullTraceSetInfoCompletion(
    _In_ PDEVICE_OBJECT DeviceObject,
    _In_ PIRP Irp,
    _In_ PVOID Context
    )
{
    UNREFERENCED_PARAMETER(DeviceObject);
    UNREFERENCED_PARAMETER(Context);

    if (Irp->PendingReturned) {
        IoMarkIrpPending(Irp);
    }

    return STATUS_SUCCESS;
}

//
// Check if file name ends with target extensions
//
BOOLEAN
NullTraceIsTargetFile(
    _In_ PUNICODE_STRING FileName
    )
{
    UNICODE_STRING logExt, evtxExt;
    USHORT nameLength;

    if (FileName == NULL || FileName->Buffer == NULL || FileName->Length < 8) {
        return FALSE;
    }

    nameLength = FileName->Length / sizeof(WCHAR);

    RtlInitUnicodeString(&logExt, NULLTRACE_LOG_EXTENSION);
    RtlInitUnicodeString(&evtxExt, NULLTRACE_EVTX_EXTENSION);

    //
    // Check for .log extension (case insensitive)
    //
    if (nameLength >= (logExt.Length / sizeof(WCHAR))) {
        UNICODE_STRING suffix;
        suffix.Buffer = &FileName->Buffer[nameLength - (logExt.Length / sizeof(WCHAR))];
        suffix.Length = logExt.Length;
        suffix.MaximumLength = logExt.Length;

        if (RtlCompareUnicodeString(&suffix, &logExt, TRUE) == 0) {
            return TRUE;
        }
    }

    //
    // Check for .evtx extension (case insensitive)
    //
    if (nameLength >= (evtxExt.Length / sizeof(WCHAR))) {
        UNICODE_STRING suffix;
        suffix.Buffer = &FileName->Buffer[nameLength - (evtxExt.Length / sizeof(WCHAR))];
        suffix.Length = evtxExt.Length;
        suffix.MaximumLength = evtxExt.Length;

        if (RtlCompareUnicodeString(&suffix, &evtxExt, TRUE) == 0) {
            return TRUE;
        }
    }

    return FALSE;
}

//
// Get file name from IRP
//
NTSTATUS
NullTraceGetFileNameFromIrp(
    _In_ PIRP Irp,
    _Out_ PUNICODE_STRING FileName
    )
{
    PIO_STACK_LOCATION irpStack;
    PFILE_OBJECT fileObject;

    irpStack = IoGetCurrentIrpStackLocation(Irp);
    fileObject = irpStack->FileObject;

    if (fileObject == NULL || fileObject->FileName.Buffer == NULL) {
        return STATUS_INVALID_PARAMETER;
    }

    //
    // Allocate buffer for filename
    //
    FileName->MaximumLength = fileObject->FileName.Length + sizeof(WCHAR);
    FileName->Buffer = (PWCH)ExAllocatePoolWithTag(PagedPool, FileName->MaximumLength, NULLTRACE_POOL_TAG);
    
    if (FileName->Buffer == NULL) {
        return STATUS_INSUFFICIENT_RESOURCES;
    }

    //
    // Copy filename
    //
    RtlCopyUnicodeString(FileName, &fileObject->FileName);

    return STATUS_SUCCESS;
}

//
// Free filename buffer
//
VOID
NullTraceFreeFileName(
    _In_ PUNICODE_STRING FileName
    )
{
    if (FileName->Buffer != NULL) {
        ExFreePoolWithTag(FileName->Buffer, NULLTRACE_POOL_TAG);
        FileName->Buffer = NULL;
        FileName->Length = 0;
        FileName->MaximumLength = 0;
    }
}

//
// Add data to ring buffer (thread-safe)
//
NTSTATUS
NullTraceAddToRingBuffer(
    _In_ ULONG OperationType,
    _In_ PUNICODE_STRING FileName,
    _In_opt_ PVOID Data,
    _In_ ULONG DataLength
    )
{
    PNULLTRACE_BUFFER_ENTRY entry;
    ULONG totalEntrySize;
    ULONG fileNameLength;

    if (g_NullTraceData.RingBuffer == NULL || g_NullTraceData.DriverUnloading) {
        return STATUS_UNSUCCESSFUL;
    }

    //
    // Calculate entry size
    //
    fileNameLength = min(FileName->Length, NULLTRACE_MAX_FILENAME_LENGTH * sizeof(WCHAR));
    totalEntrySize = sizeof(NULLTRACE_BUFFER_ENTRY) + DataLength;

    if (totalEntrySize > NULLTRACE_RING_BUFFER_SIZE / 4) {
        // Entry too large, truncate data
        DataLength = (NULLTRACE_RING_BUFFER_SIZE / 4) - sizeof(NULLTRACE_BUFFER_ENTRY);
        totalEntrySize = sizeof(NULLTRACE_BUFFER_ENTRY) + DataLength;
    }

    WdfSpinLockAcquire(g_NullTraceData.RingBufferSpinLock);

    //
    // Make room if buffer would overflow
    //
    while ((g_NullTraceData.RingBufferFull) || 
           ((g_NullTraceData.RingBufferHead + totalEntrySize) % NULLTRACE_RING_BUFFER_SIZE) == g_NullTraceData.RingBufferTail) {
        
        if (g_NullTraceData.RingBufferTail == g_NullTraceData.RingBufferHead) {
            g_NullTraceData.RingBufferFull = FALSE;
            break;
        }

        // Skip over the entry at tail
        entry = (PNULLTRACE_BUFFER_ENTRY)&g_NullTraceData.RingBuffer[g_NullTraceData.RingBufferTail];
        g_NullTraceData.RingBufferTail = (g_NullTraceData.RingBufferTail + 
                                          sizeof(NULLTRACE_BUFFER_ENTRY) + entry->DataLength) % 
                                          NULLTRACE_RING_BUFFER_SIZE;
        
        InterlockedIncrement(&g_NullTraceData.Statistics.RingBufferOverflows);
    }

    //
    // Add new entry
    //
    entry = (PNULLTRACE_BUFFER_ENTRY)&g_NullTraceData.RingBuffer[g_NullTraceData.RingBufferHead];
    KeQuerySystemTime(&entry->Timestamp);
    entry->DataLength = DataLength;
    entry->OperationType = OperationType;

    //
    // Copy filename
    //
    RtlZeroMemory(entry->FileName, sizeof(entry->FileName));
    if (fileNameLength > 0) {
        RtlCopyMemory(entry->FileName, FileName->Buffer, fileNameLength);
    }

    //
    // Copy data if provided
    //
    if (DataLength > 0 && Data != NULL) {
        RtlCopyMemory((PUCHAR)entry + sizeof(NULLTRACE_BUFFER_ENTRY), Data, DataLength);
    }

    //
    // Update head pointer
    //
    g_NullTraceData.RingBufferHead = (g_NullTraceData.RingBufferHead + totalEntrySize) % 
                                     NULLTRACE_RING_BUFFER_SIZE;

    if (g_NullTraceData.RingBufferHead == g_NullTraceData.RingBufferTail) {
        g_NullTraceData.RingBufferFull = TRUE;
    }

    WdfSpinLockRelease(g_NullTraceData.RingBufferSpinLock);

    return STATUS_SUCCESS;
}

//
// Update statistics (thread-safe)
//
VOID
NullTraceUpdateStatistics(
    _In_ ULONG64 BytesDropped,
    _In_ BOOLEAN FileIntercepted,
    _In_ BOOLEAN WriteBlocked,
    _In_ BOOLEAN CreateCaptured,
    _In_ BOOLEAN SetInfoBlocked
    )
{
    WdfSpinLockAcquire(g_NullTraceData.StatisticsLock);

    g_NullTraceData.Statistics.TotalBytesDropped += BytesDropped;
    
    if (FileIntercepted) {
        g_NullTraceData.Statistics.TotalFilesIntercepted++;
    }
    
    if (WriteBlocked) {
        g_NullTraceData.Statistics.TotalWritesBlocked++;
    }

    if (CreateCaptured) {
        g_NullTraceData.Statistics.TotalCreatesCaptured++;
    }

    if (SetInfoBlocked) {
        g_NullTraceData.Statistics.TotalSetInfoBlocked++;
    }

    WdfSpinLockRelease(g_NullTraceData.StatisticsLock);
}

//
// Check if it's safe to filter this request
//
BOOLEAN
NullTraceSafeToFilter(
    _In_ PIRP Irp
    )
{
    PIO_STACK_LOCATION irpStack;

    //
    // Check stack depth
    //
    if (IoGetRemainingStackSize() < (NULLTRACE_MAX_STACK_LOCATIONS * sizeof(IO_STACK_LOCATION))) {
        return FALSE;
    }

    irpStack = IoGetCurrentIrpStackLocation(Irp);

    //
    // Check if this is a paging file operation
    //
    if (FlagOn(Irp->Flags, IRP_PAGING_IO)) {
        return FALSE;
    }

    //
    // Check if this is a system thread
    //
    if (FlagOn(Irp->Flags, IRP_SYNCHRONOUS_PAGING_IO)) {
        return FALSE;
    }

    return TRUE;
}

//
// Secure cleanup of all resources
//
VOID
NullTraceSecureCleanup(
    VOID
    )
{
    //
    // Securely zero ring buffer
    //
    if (g_NullTraceData.RingBuffer != NULL) {
        RtlSecureZeroMemory(g_NullTraceData.RingBuffer, NULLTRACE_RING_BUFFER_SIZE);
        ExFreePoolWithTag(g_NullTraceData.RingBuffer, NULLTRACE_POOL_TAG);
        g_NullTraceData.RingBuffer = NULL;
    }

    //
    // Zero statistics
    //
    RtlSecureZeroMemory(&g_NullTraceData.Statistics, sizeof(NULLTRACE_STATS));

    DbgPrint("NullTrace: Secure cleanup completed\n");
} 