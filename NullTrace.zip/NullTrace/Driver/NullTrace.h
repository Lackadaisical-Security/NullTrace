//
// NullTrace.h - Production-Grade KMDF Anti-Forensics Driver
// © Lackadaisical Security, 2025
//

#pragma once

#include <ntddk.h>
#include <wdf.h>
#include <ntifs.h>
#include <ntstrsafe.h>
#include <suppress.h>

#pragma prefast(disable:__WARNING_ENCODE_MEMBER_FUNCTION_POINTER, "Not applicable for kernel mode drivers")

//
// Pool tags (must be 4 characters in reverse order for little-endian)
//
#define NULLTRACE_POOL_TAG          'TluN'  // NulT
#define NULLTRACE_CONTEXT_TAG       'TxuN'  // NuxT

//
// Version information
//
#define NULLTRACE_MAJOR_VERSION     1
#define NULLTRACE_MINOR_VERSION     0

//
// Device and symbolic link names
//
#define NULLTRACE_DEVICE_NAME       L"\\Device\\NullTrace"
#define NULLTRACE_SYMBOLIC_LINK     L"\\DosDevices\\NullTrace"

//
// File system device names to attach to
//
#define NTFS_DEVICE_NAME            L"\\FileSystem\\Ntfs"
#define FASTFAT_DEVICE_NAME         L"\\FileSystem\\Fastfat"

//
// IOCTL definitions
//
#define IOCTL_NULLTRACE_STATS \
    CTL_CODE(FILE_DEVICE_UNKNOWN, 0x800, METHOD_BUFFERED, FILE_ANY_ACCESS)

//
// Ring buffer configuration
//
#define NULLTRACE_RING_BUFFER_SIZE      (64 * 1024)  // 64 KB
#define NULLTRACE_MAX_STACK_LOCATIONS   4
#define NULLTRACE_MAX_FILENAME_LENGTH   512

//
// Target file extensions (case insensitive)
//
#define NULLTRACE_LOG_EXTENSION     L".log"
#define NULLTRACE_EVTX_EXTENSION    L".evtx"

//
// Statistics structure exposed via IOCTL
//
typedef struct _NULLTRACE_STATS {
    ULONG64 TotalBytesDropped;
    ULONG64 TotalFilesIntercepted;
    ULONG64 TotalWritesBlocked;
    ULONG64 TotalCreatesCaptured;
    ULONG64 TotalSetInfoBlocked;
    ULONG   RingBufferOverflows;
    ULONG   CurrentRingBufferUsage;
    LARGE_INTEGER DriverStartTime;
} NULLTRACE_STATS, *PNULLTRACE_STATS;

//
// Ring buffer entry header
//
typedef struct _NULLTRACE_BUFFER_ENTRY {
    LARGE_INTEGER Timestamp;
    ULONG DataLength;
    ULONG OperationType;  // 1=CREATE, 2=WRITE, 3=SETINFO
    WCHAR FileName[NULLTRACE_MAX_FILENAME_LENGTH];
    // Variable length data follows
} NULLTRACE_BUFFER_ENTRY, *PNULLTRACE_BUFFER_ENTRY;

//
// Device extension for filter devices
//
typedef struct _NULLTRACE_DEVICE_EXTENSION {
    WDFDEVICE Device;
    PDEVICE_OBJECT AttachedToDeviceObject;
    PDEVICE_OBJECT FileSystemDeviceObject;
    UNICODE_STRING DeviceName;
    BOOLEAN IsAttached;
    LIST_ENTRY ListEntry;
} NULLTRACE_DEVICE_EXTENSION, *PNULLTRACE_DEVICE_EXTENSION;

WDF_DECLARE_CONTEXT_TYPE_WITH_NAME(NULLTRACE_DEVICE_EXTENSION, NullTraceGetDeviceExtension)

//
// IRP context for asynchronous operations
//
typedef struct _NULLTRACE_IRP_CONTEXT {
    WDFREQUEST OriginalRequest;
    PDEVICE_OBJECT TargetDeviceObject;
    PIRP OriginalIrp;
    BOOLEAN IsTargetFile;
    UNICODE_STRING FileName;
} NULLTRACE_IRP_CONTEXT, *PNULLTRACE_IRP_CONTEXT;

WDF_DECLARE_CONTEXT_TYPE_WITH_NAME(NULLTRACE_IRP_CONTEXT, NullTraceGetIrpContext)

//
// Global driver data structure
//
typedef struct _NULLTRACE_GLOBAL_DATA {
    // WDF objects
    WDFDRIVER Driver;
    WDFDEVICE ControlDevice;
    
    // Filter device list
    LIST_ENTRY FilterDeviceList;
    KSPIN_LOCK FilterDeviceListLock;
    
    // Statistics (protected by StatisticsLock)
    NULLTRACE_STATS Statistics;
    WDFSPINLOCK StatisticsLock;
    
    // Ring buffer (protected by RingBufferSpinLock)
    PUCHAR RingBuffer;
    ULONG RingBufferHead;
    ULONG RingBufferTail;
    BOOLEAN RingBufferFull;
    WDFSPINLOCK RingBufferSpinLock;
    
    // Lookaside lists for performance
    WDFLOOKASIDE BufferEntryLookaside;
    WDFLOOKASIDE FileNameLookaside;
    
    // Driver state
    BOOLEAN DriverUnloading;
    
    // File system notification
    PDEVICE_OBJECT NotificationDeviceObject;
    
} NULLTRACE_GLOBAL_DATA, *PNULLTRACE_GLOBAL_DATA;

//
// Function prototypes
//

// Driver entry and events
DRIVER_INITIALIZE DriverEntry;
NTSTATUS DriverEntry(
    _In_ PDRIVER_OBJECT DriverObject,
    _In_ PUNICODE_STRING RegistryPath
    );

EVT_WDF_DRIVER_UNLOAD NullTraceEvtDriverUnload;
VOID NullTraceEvtDriverUnload(
    _In_ WDFDRIVER Driver
    );

// Device events
EVT_WDF_DEVICE_CONTEXT_CLEANUP NullTraceEvtDeviceContextCleanup;
VOID NullTraceEvtDeviceContextCleanup(
    _In_ WDFOBJECT Device
    );

// Control device I/O events
EVT_WDF_IO_QUEUE_IO_DEVICE_CONTROL NullTraceEvtIoDeviceControl;
VOID NullTraceEvtIoDeviceControl(
    _In_ WDFQUEUE Queue,
    _In_ WDFREQUEST Request,
    _In_ size_t OutputBufferLength,
    _In_ size_t InputBufferLength,
    _In_ ULONG IoControlCode
    );

// IRP dispatch routines
DRIVER_DISPATCH NullTraceDispatchCreate;
NTSTATUS NullTraceDispatchCreate(
    _In_ PDEVICE_OBJECT DeviceObject,
    _In_ PIRP Irp
    );

DRIVER_DISPATCH NullTraceDispatchWrite;
NTSTATUS NullTraceDispatchWrite(
    _In_ PDEVICE_OBJECT DeviceObject,
    _In_ PIRP Irp
    );

DRIVER_DISPATCH NullTraceDispatchSetInformation;
NTSTATUS NullTraceDispatchSetInformation(
    _In_ PDEVICE_OBJECT DeviceObject,
    _In_ PIRP Irp
    );

DRIVER_DISPATCH NullTraceDispatchDefault;
NTSTATUS NullTraceDispatchDefault(
    _In_ PDEVICE_OBJECT DeviceObject,
    _In_ PIRP Irp
    );

// File system notification
VOID NullTraceFileSystemNotification(
    _In_ PDEVICE_OBJECT DeviceObject,
    _In_ BOOLEAN FsActive
    );

NTSTATUS NullTraceAttachToFileSystem(
    _In_ PDEVICE_OBJECT FileSystemDeviceObject
    );

VOID NullTraceDetachFromFileSystem(
    _In_ PNULLTRACE_DEVICE_EXTENSION DeviceExtension
    );

VOID NullTraceAttachToExistingFileSystems(
    VOID
    );

VOID NullTraceDetachFromAllFileSystems(
    VOID
    );

NTSTATUS NullTraceCreateControlDevice(
    _In_ WDFDRIVER Driver
    );

// IRP completion routines
IO_COMPLETION_ROUTINE NullTraceCreateCompletion;
NTSTATUS NullTraceCreateCompletion(
    _In_ PDEVICE_OBJECT DeviceObject,
    _In_ PIRP Irp,
    _In_ PVOID Context
    );

IO_COMPLETION_ROUTINE NullTraceWriteCompletion;
NTSTATUS NullTraceWriteCompletion(
    _In_ PDEVICE_OBJECT DeviceObject,
    _In_ PIRP Irp,
    _In_ PVOID Context
    );

IO_COMPLETION_ROUTINE NullTraceSetInfoCompletion;
NTSTATUS NullTraceSetInfoCompletion(
    _In_ PDEVICE_OBJECT DeviceObject,
    _In_ PIRP Irp,
    _In_ PVOID Context
    );

// Utility functions
BOOLEAN NullTraceIsTargetFile(
    _In_ PUNICODE_STRING FileName
    );

NTSTATUS NullTraceGetFileNameFromIrp(
    _In_ PIRP Irp,
    _Out_ PUNICODE_STRING FileName
    );

VOID NullTraceFreeFileName(
    _In_ PUNICODE_STRING FileName
    );

NTSTATUS NullTraceAddToRingBuffer(
    _In_ ULONG OperationType,
    _In_ PUNICODE_STRING FileName,
    _In_opt_ PVOID Data,
    _In_ ULONG DataLength
    );

VOID NullTraceUpdateStatistics(
    _In_ ULONG64 BytesDropped,
    _In_ BOOLEAN FileIntercepted,
    _In_ BOOLEAN WriteBlocked,
    _In_ BOOLEAN CreateCaptured,
    _In_ BOOLEAN SetInfoBlocked
    );

BOOLEAN NullTraceSafeToFilter(
    _In_ PIRP Irp
    );

VOID NullTraceSecureCleanup(
    VOID
    );

// Global data
extern NULLTRACE_GLOBAL_DATA g_NullTraceData; 